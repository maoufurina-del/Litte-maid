package com.customplayermodel;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Handle network packet untuk sync model antar player.
 * Ringan: hanya kirim nama model + UUID player (tidak ada data model besar).
 */
public class CPMNetwork {

    // Packet ID: client -> server, memberitahu model yang dipilih
    public static final Identifier SYNC_MODEL_ID =
            Identifier.of(CustomPlayerModelMod.MOD_ID, "sync_model");

    // Packet ID: client -> server, ganti model maid
    public static final Identifier SYNC_MAID_MODEL_ID =
            Identifier.of(CustomPlayerModelMod.MOD_ID, "sync_maid_model");

    public static void registerPackets() {
        // Player model sync
        ServerPlayNetworking.registerGlobalReceiver(
            ModelSyncPayload.ID,
            (payload, context) -> {
                context.server().execute(() -> {
                    CPMServerState.setPlayerModel(
                        context.player().getUuid(),
                        payload.modelId()
                    );
                    CustomPlayerModelMod.LOGGER.info(
                        "[CPM] Player {} set model: {}",
                        context.player().getName().getString(),
                        payload.modelId()
                    );
                });
            }
        );

        // Maid model sync
        ServerPlayNetworking.registerGlobalReceiver(
            MaidModelSyncPayload.ID,
            (payload, context) -> {
                context.server().execute(() -> {
                    net.minecraft.server.world.ServerWorld world =
                        (net.minecraft.server.world.ServerWorld) context.player().getWorld();
                    net.minecraft.entity.Entity entity = world.getEntityById(payload.maidEntityId());
                    if (entity instanceof com.customplayermodel.entity.MaidEntity maid) {
                        // Hanya owner atau creative player yang boleh ganti model
                        boolean isOwner = context.player().getUuid().equals(maid.getOwnerUuid());
                        boolean isCreative = context.player().isCreative();
                        if (isOwner || isCreative) {
                            maid.setModelId(payload.modelId());
                            CustomPlayerModelMod.LOGGER.info(
                                "[CPM] Maid #{} model set to: {}",
                                payload.maidEntityId(), payload.modelId()
                            );
                        }
                    }
                });
            }
        );
    }

    // Payload: player model sync
    public record ModelSyncPayload(String modelId) implements CustomPayload {
        public static final Id<ModelSyncPayload> ID =
            new Id<>(Identifier.of(CustomPlayerModelMod.MOD_ID, "sync_model"));

        public static final PacketCodec<PacketByteBuf, ModelSyncPayload> CODEC =
            PacketCodec.of(
                (value, buf) -> buf.writeString(value.modelId()),
                buf -> new ModelSyncPayload(buf.readString(64))
            );

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    // Payload: maid model sync (entity ID + model ID)
    public record MaidModelSyncPayload(int maidEntityId, String modelId) implements CustomPayload {
        public static final Id<MaidModelSyncPayload> ID =
            new Id<>(Identifier.of(CustomPlayerModelMod.MOD_ID, "sync_maid_model"));

        public static final PacketCodec<PacketByteBuf, MaidModelSyncPayload> CODEC =
            PacketCodec.of(
                (value, buf) -> { buf.writeInt(value.maidEntityId()); buf.writeString(value.modelId()); },
                buf -> new MaidModelSyncPayload(buf.readInt(), buf.readString(64))
            );

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }
}
