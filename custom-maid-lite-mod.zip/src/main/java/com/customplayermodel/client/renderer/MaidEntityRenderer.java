package com.customplayermodel.client.renderer;

import com.customplayermodel.client.model.CPMModelManager;
import com.customplayermodel.client.model.CPMModelData;
import com.customplayermodel.entity.MaidEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

import java.util.Optional;

/**
 * Renderer untuk MaidEntity.
 *
 * Logika render:
 * 1. Jika maid punya modelId, cari di CPMModelManager → render custom (YSM)
 * 2. Jika tidak ada / gagal → fallback ke render placeholder simpel
 *
 * Optimasi RAM:
 * - Tidak menyimpan state per-entity di renderer
 * - Lazy load model via CPMModelManager (LRU cache max 10 model)
 */
public class MaidEntityRenderer extends MobEntityRenderer<MaidEntity, MaidEntityModel> {

    private static final Identifier FALLBACK_TEXTURE =
        Identifier.of("customplayermodel", "textures/entity/maid/default.png");

    public MaidEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new MaidEntityModel(ctx.getPart(MaidEntityModel.LAYER_LOCATION)), 0.3f);
    }

    @Override
    public Identifier getTexture(MaidEntity entity) {
        // Cek custom model texture
        String modelId = entity.getModelId();
        if (!modelId.isBlank()) {
            Optional<CPMModelData> data = CPMModelManager.getInstance().getModel(modelId);
            if (data.isPresent() && !data.get().getTextureFile().isBlank()) {
                return data.get().getTextureIdentifier();
            }
        }
        return FALLBACK_TEXTURE;
    }

    @Override
    public void render(MaidEntity entity, float yaw, float tickDelta,
                       MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();

        // Skala sedikit lebih kecil dari player (style maid imut)
        float scale = 0.9f;
        matrices.scale(scale, scale, scale);

        // Jika duduk (sitting), turunkan posisi
        if (entity.isInSittingPose()) {
            matrices.translate(0, -0.3, 0);
        }

        String modelId = entity.getModelId();
        if (!modelId.isBlank()) {
            Optional<CPMModelData> modelData = CPMModelManager.getInstance().getModel(modelId);
            if (modelData.isPresent()) {
                // Render custom YSM model
                renderCustomModel(entity, modelData.get(), yaw, tickDelta,
                    matrices, vertexConsumers, light);
                matrices.pop();
                return;
            }
        }

        // Fallback: render default via super (MaidEntityModel)
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
        matrices.pop();
    }

    /**
     * Render maid dengan custom model (YSM format).
     * Tahap 1: placeholder geometry. Tahap 2: GeckoLib full animation.
     */
    private void renderCustomModel(MaidEntity entity, CPMModelData modelData,
                                   float yaw, float tickDelta, MatrixStack matrices,
                                   VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - yaw));

        Identifier texture = modelData.getTextureIdentifier();
        VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntitySolid(texture));

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        int overlay = OverlayTexture.DEFAULT_UV;

        // Body placeholder (akan diganti GeckoLib di tahap selanjutnya)
        renderBox(matrix, consumer, light, overlay,
            -0.2f, 0.6f, -0.1f,   // min x,y,z
             0.2f, 1.2f,  0.1f);  // max x,y,z

        // Head placeholder
        renderBox(matrix, consumer, light, overlay,
            -0.15f, 1.2f, -0.15f,
             0.15f, 1.55f, 0.15f);

        // Left leg
        renderBox(matrix, consumer, light, overlay,
            -0.18f, 0.0f, -0.05f,
            -0.04f, 0.60f, 0.05f);

        // Right leg
        renderBox(matrix, consumer, light, overlay,
             0.04f, 0.0f, -0.05f,
             0.18f, 0.60f, 0.05f);

        matrices.pop();
    }

    /** Helper: render kotak 6 sisi dari min ke max. */
    private void renderBox(Matrix4f m, VertexConsumer v, int light, int overlay,
                           float x0, float y0, float z0,
                           float x1, float y1, float z1) {
        // Front
        quad(m, v, light, overlay, x0,y1,z1, x0,y0,z1, x1,y0,z1, x1,y1,z1, 0,0,1);
        // Back
        quad(m, v, light, overlay, x1,y1,z0, x1,y0,z0, x0,y0,z0, x0,y1,z0, 0,0,-1);
        // Top
        quad(m, v, light, overlay, x0,y1,z0, x0,y1,z1, x1,y1,z1, x1,y1,z0, 0,1,0);
        // Bottom
        quad(m, v, light, overlay, x1,y0,z0, x1,y0,z1, x0,y0,z1, x0,y0,z0, 0,-1,0);
        // Right
        quad(m, v, light, overlay, x1,y1,z1, x1,y0,z1, x1,y0,z0, x1,y1,z0, 1,0,0);
        // Left
        quad(m, v, light, overlay, x0,y1,z0, x0,y0,z0, x0,y0,z1, x0,y1,z1, -1,0,0);
    }

    private void quad(Matrix4f m, VertexConsumer v, int light, int overlay,
                      float x0,float y0,float z0,
                      float x1,float y1,float z1,
                      float x2,float y2,float z2,
                      float x3,float y3,float z3,
                      float nx,float ny,float nz) {
        v.vertex(m,x0,y0,z0).color(255,255,255,255).texture(0,0).overlay(overlay).light(light).normal(nx,ny,nz);
        v.vertex(m,x1,y1,z1).color(255,255,255,255).texture(0,1).overlay(overlay).light(light).normal(nx,ny,nz);
        v.vertex(m,x2,y2,z2).color(255,255,255,255).texture(1,1).overlay(overlay).light(light).normal(nx,ny,nz);
        v.vertex(m,x3,y3,z3).color(255,255,255,255).texture(1,0).overlay(overlay).light(light).normal(nx,ny,nz);
    }
}
