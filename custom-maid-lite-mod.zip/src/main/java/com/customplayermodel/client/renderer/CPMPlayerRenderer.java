package com.customplayermodel.client.renderer;

import com.customplayermodel.CustomPlayerModelMod;
import com.customplayermodel.client.model.CPMModelData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

/**
 * Renderer untuk custom player model.
 *
 * Tahap 1 (scaffold): render texture default Steve dengan posisi model custom.
 * Tahap 2 (TODO): integrasi penuh GeckoLib untuk animasi BBModel / YSM.
 *
 * Optimasi RAM:
 * - Tidak menyimpan buffer besar per frame
 * - Reuse MatrixStack transforms
 * - Texture dimuat lazy oleh Minecraft texture manager
 */
public class CPMPlayerRenderer {

    /**
     * Render player dengan custom model.
     * Dipanggil dari mixin saat player memiliki model.
     */
    public static void render(
            AbstractClientPlayerEntity player,
            CPMModelData modelData,
            float yaw,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light
    ) {
        matrices.push();

        try {
            // Rotasi menghadap arah player
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - yaw));

            // Offset posisi agar berdiri di atas kaki
            matrices.translate(0, 0, 0);

            // Ambil texture model (fallback ke skin player jika tidak ada)
            Identifier texture = resolveTexture(player, modelData);

            // === TAHAP 1: Render kotak sederhana sebagai placeholder ===
            // Ini akan digantikan integrasi GeckoLib penuh di tahap berikutnya
            VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntitySolid(texture));
            renderPlaceholderCube(matrices, consumer, light);

        } catch (Exception e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Render error untuk {}: {}", modelData.getModelId(), e.getMessage());
        } finally {
            matrices.pop();
        }
    }

    /**
     * Resolve texture: pakai texture model jika ada, fallback ke skin player.
     */
    private static Identifier resolveTexture(AbstractClientPlayerEntity player, CPMModelData modelData) {
        String textureFile = modelData.getTextureFile();
        if (textureFile != null && !textureFile.isBlank()) {
            return modelData.getTextureIdentifier();
        }
        // Fallback ke skin player
        return player.getSkinTextures().texture();
    }

    /**
     * Placeholder render: kotak 1x2x0.5 (silhouette player).
     * Akan digantikan GeckoLib renderer di tahap selanjutnya.
     */
    private static void renderPlaceholderCube(MatrixStack matrices, VertexConsumer consumer, int light) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        float x0 = -0.25f, x1 = 0.25f;
        float y0 = 0f,     y1 = 1.8f;
        float z0 = -0.125f, z1 = 0.125f;

        int overlay = OverlayTexture.DEFAULT_UV;

        // Front face
        consumer.vertex(matrix, x0, y1, z1).color(255,255,255,255).texture(0,0).overlay(overlay).light(light).normal(0,0,1);
        consumer.vertex(matrix, x0, y0, z1).color(255,255,255,255).texture(0,1).overlay(overlay).light(light).normal(0,0,1);
        consumer.vertex(matrix, x1, y0, z1).color(255,255,255,255).texture(1,1).overlay(overlay).light(light).normal(0,0,1);
        consumer.vertex(matrix, x1, y1, z1).color(255,255,255,255).texture(1,0).overlay(overlay).light(light).normal(0,0,1);

        // Back face
        consumer.vertex(matrix, x1, y1, z0).color(255,255,255,255).texture(0,0).overlay(overlay).light(light).normal(0,0,-1);
        consumer.vertex(matrix, x1, y0, z0).color(255,255,255,255).texture(0,1).overlay(overlay).light(light).normal(0,0,-1);
        consumer.vertex(matrix, x0, y0, z0).color(255,255,255,255).texture(1,1).overlay(overlay).light(light).normal(0,0,-1);
        consumer.vertex(matrix, x0, y1, z0).color(255,255,255,255).texture(1,0).overlay(overlay).light(light).normal(0,0,-1);
    }
}
