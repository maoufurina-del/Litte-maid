package com.customplayermodel.client.renderer;

import com.customplayermodel.CustomPlayerModelMod;
import com.customplayermodel.entity.MaidEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Model default maid (fallback jika tidak ada model YSM).
 * Bentuk mirip player tapi lebih kecil — dirender oleh MaidEntityRenderer.
 * Layer ini didaftarkan di EntityModelLayerRegistry client-side.
 */
public class MaidEntityModel extends EntityModel<MaidEntity> {

    public static final EntityModelLayer LAYER_LOCATION = new EntityModelLayer(
        Identifier.of(CustomPlayerModelMod.MOD_ID, "maid"), "main"
    );

    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart hair; // rambut panjang (bagian khas maid)

    public MaidEntityModel(ModelPart root) {
        this.head     = root.getChild("head");
        this.body     = root.getChild("body");
        this.leftLeg  = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.leftArm  = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.hair     = root.getChild("hair");
    }

    /** TexturedModelData untuk EntityModelLayerRegistry. */
    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        // Head (UV sama seperti player Minecraft)
        root.addChild("head",
            ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -8f, -4f, 8, 8, 8),
            ModelTransform.pivot(0f, 0f, 0f));

        // Hair (rambut panjang di belakang, ciri khas maid)
        root.addChild("hair",
            ModelPartBuilder.create().uv(32, 0).cuboid(-4f, -8f, 0f, 8, 14, 1),
            ModelTransform.pivot(0f, 0f, 4f));

        // Body
        root.addChild("body",
            ModelPartBuilder.create().uv(16, 16).cuboid(-4f, 0f, -2f, 8, 12, 4),
            ModelTransform.pivot(0f, 0f, 0f));

        // Left Arm
        root.addChild("left_arm",
            ModelPartBuilder.create().uv(32, 48).cuboid(-1f, -2f, -2f, 3, 12, 4),
            ModelTransform.pivot(5f, 2f, 0f));

        // Right Arm
        root.addChild("right_arm",
            ModelPartBuilder.create().uv(40, 16).cuboid(-2f, -2f, -2f, 3, 12, 4),
            ModelTransform.pivot(-5f, 2f, 0f));

        // Left Leg
        root.addChild("left_leg",
            ModelPartBuilder.create().uv(16, 48).cuboid(-2f, 0f, -2f, 4, 12, 4),
            ModelTransform.pivot(2f, 12f, 0f));

        // Right Leg
        root.addChild("right_leg",
            ModelPartBuilder.create().uv(0, 16).cuboid(-2f, 0f, -2f, 4, 12, 4),
            ModelTransform.pivot(-2f, 12f, 0f));

        return TexturedModelData.of(modelData, 64, 64);
    }

    @Override
    public void setAngles(MaidEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        float speed = 1.0f;

        // Head look
        this.head.yaw   = headYaw   * (float)(Math.PI / 180.0);
        this.head.pitch = headPitch * (float)(Math.PI / 180.0);
        this.hair.yaw   = this.head.yaw;

        // Leg swing saat jalan — lebih lambat dari player (imut)
        this.rightLeg.pitch = MathHelper.cos(limbAngle * 0.6662f       ) * 1.0f * limbDistance * speed;
        this.leftLeg.pitch  = MathHelper.cos(limbAngle * 0.6662f + (float)Math.PI) * 1.0f * limbDistance * speed;

        // Arm swing berlawanan kaki
        this.rightArm.pitch = MathHelper.cos(limbAngle * 0.6662f + (float)Math.PI) * 0.7f * limbDistance * speed;
        this.leftArm.pitch  = MathHelper.cos(limbAngle * 0.6662f       ) * 0.7f * limbDistance * speed;

        // Jika duduk
        if (entity.isInSittingPose()) {
            this.rightLeg.pitch = -(float)Math.PI / 4f;
            this.leftLeg.pitch  = -(float)Math.PI / 4f;
            this.rightLeg.yaw   =  (float)Math.PI / 8f;
            this.leftLeg.yaw    = -(float)Math.PI / 8f;
        } else {
            this.rightLeg.yaw = 0;
            this.leftLeg.yaw  = 0;
        }

        // Animasi "idle" — tangan sedikit bergoyang halus saat diam
        if (limbDistance < 0.01f) {
            float idleSwing = MathHelper.sin(animationProgress * 0.05f) * 0.04f;
            this.leftArm.pitch  = idleSwing;
            this.rightArm.pitch = -idleSwing;
        }
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       int color) {
        head.render(matrices, vertices, light, overlay, color);
        hair.render(matrices, vertices, light, overlay, color);
        body.render(matrices, vertices, light, overlay, color);
        leftLeg.render(matrices, vertices, light, overlay, color);
        rightLeg.render(matrices, vertices, light, overlay, color);
        leftArm.render(matrices, vertices, light, overlay, color);
        rightArm.render(matrices, vertices, light, overlay, color);
    }
}
