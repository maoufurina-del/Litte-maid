package com.customplayermodel.client.model;

import com.google.gson.JsonObject;
import net.minecraft.util.Identifier;

/**
 * Data model player custom.
 * Format JSON sederhana yang kompatibel subset YSM:
 * {
 *   "name": "Yae Miko",
 *   "author": "Author Name",
 *   "texture": "yae_miko.png",   // relatif ke folder models/
 *   "geometry": { ... }          // data geometri BBModel / GeckoLib
 * }
 */
public class CPMModelData {

    private final String modelId;
    private final String displayName;
    private final String author;
    private final String textureFile;
    private final JsonObject geometry;

    private CPMModelData(String modelId, String displayName, String author,
                          String textureFile, JsonObject geometry) {
        this.modelId = modelId;
        this.displayName = displayName;
        this.author = author;
        this.textureFile = textureFile;
        this.geometry = geometry;
    }

    public static CPMModelData fromJson(String modelId, JsonObject json) {
        String name = json.has("name") ? json.get("name").getAsString() : modelId;
        String author = json.has("author") ? json.get("author").getAsString() : "Unknown";
        String texture = json.has("texture") ? json.get("texture").getAsString() : "";
        JsonObject geo = json.has("geometry") ? json.getAsJsonObject("geometry") : new JsonObject();
        return new CPMModelData(modelId, name, author, texture, geo);
    }

    public String getModelId() { return modelId; }
    public String getDisplayName() { return displayName; }
    public String getAuthor() { return author; }
    public String getTextureFile() { return textureFile; }
    public JsonObject getGeometry() { return geometry; }

    /**
     * Identifier untuk texture, dipakai GeckoLib renderer.
     * Path: assets/customplayermodel/textures/entity/<modelId>/<textureFile>
     */
    public Identifier getTextureIdentifier() {
        return Identifier.of("customplayermodel",
                "textures/entity/" + modelId + "/" + textureFile);
    }

    @Override
    public String toString() {
        return "CPMModelData{id=" + modelId + ", name=" + displayName + "}";
    }
}
