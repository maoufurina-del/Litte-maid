package com.customplayermodel.client.model;

import com.customplayermodel.CustomPlayerModelMod;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.minecraft.util.Identifier;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Manajemen model custom player.
 * Desain ringan:
 * - Lazy loading (model hanya dimuat saat dibutuhkan)
 * - Soft limit cache 10 model agar tidak makan RAM di HP 2GB
 * - Model disimpan di folder .minecraft/config/customplayermodel/models/
 */
public class CPMModelManager {

    private static CPMModelManager instance;
    private final Gson gson = new Gson();

    // Cache model yang sudah dimuat. Max 10 entry untuk hemat RAM.
    private final LinkedHashMap<String, CPMModelData> modelCache = new LinkedHashMap<>(16, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, CPMModelData> eldest) {
            return size() > 10; // buang model paling lama tidak dipakai
        }
    };

    // Daftar model yang tersedia (nama file -> display name)
    private final Map<String, String> availableModels = new LinkedHashMap<>();

    private Path modelsDir;

    private CPMModelManager() {}

    public static CPMModelManager getInstance() {
        if (instance == null) instance = new CPMModelManager();
        return instance;
    }

    public void init() {
        // Buat folder models jika belum ada
        modelsDir = net.fabricmc.loader.api.FabricLoader.getInstance()
                .getConfigDir()
                .resolve("customplayermodel/models");
        try {
            Files.createDirectories(modelsDir);
            CustomPlayerModelMod.LOGGER.info("[CPM] Models directory: {}", modelsDir);
            refreshAvailableModels();
        } catch (IOException e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal membuat folder models: {}", e.getMessage());
        }
    }

    /**
     * Scan folder models dan perbarui daftar.
     */
    public void refreshAvailableModels() {
        availableModels.clear();
        if (modelsDir == null) return;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(modelsDir, "*.json")) {
            for (Path file : stream) {
                String fileName = file.getFileName().toString();
                String modelId = fileName.replace(".json", "");
                // Baca display name dari JSON jika ada
                String displayName = readDisplayName(file, modelId);
                availableModels.put(modelId, displayName);
            }
        } catch (IOException e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal scan folder models: {}", e.getMessage());
        }
        CustomPlayerModelMod.LOGGER.info("[CPM] {} model tersedia.", availableModels.size());
    }

    private String readDisplayName(Path file, String fallback) {
        try (Reader r = Files.newBufferedReader(file)) {
            JsonObject obj = gson.fromJson(r, JsonObject.class);
            if (obj.has("name")) return obj.get("name").getAsString();
        } catch (Exception ignored) {}
        return fallback;
    }

    /**
     * Muat model dari file JSON (format sederhana kompatibel YSM subset).
     * Lazy load: hanya muat saat pertama kali dibutuhkan.
     */
    public Optional<CPMModelData> getModel(String modelId) {
        if (modelId == null || modelId.isBlank()) return Optional.empty();
        if (modelCache.containsKey(modelId)) return Optional.of(modelCache.get(modelId));

        Path modelFile = modelsDir.resolve(modelId + ".json");
        if (!Files.exists(modelFile)) {
            CustomPlayerModelMod.LOGGER.warn("[CPM] Model tidak ditemukan: {}", modelId);
            return Optional.empty();
        }
        try (Reader r = Files.newBufferedReader(modelFile)) {
            JsonObject json = gson.fromJson(r, JsonObject.class);
            CPMModelData data = CPMModelData.fromJson(modelId, json);
            modelCache.put(modelId, data);
            CustomPlayerModelMod.LOGGER.info("[CPM] Model dimuat: {}", modelId);
            return Optional.of(data);
        } catch (Exception e) {
            CustomPlayerModelMod.LOGGER.error("[CPM] Gagal muat model {}: {}", modelId, e.getMessage());
            return Optional.empty();
        }
    }

    public Map<String, String> getAvailableModels() {
        return Collections.unmodifiableMap(availableModels);
    }

    public Path getModelsDir() {
        return modelsDir;
    }

    /** Bersihkan semua cache (dipanggil saat shutdown untuk bebaskan RAM). */
    public void clearAll() {
        modelCache.clear();
        availableModels.clear();
    }
}
