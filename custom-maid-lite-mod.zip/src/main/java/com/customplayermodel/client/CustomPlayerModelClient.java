package com.customplayermodel.client;

import com.customplayermodel.CustomPlayerModelMod;
import com.customplayermodel.client.model.CPMModelManager;
import com.customplayermodel.client.screen.ModelSelectorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class CustomPlayerModelClient implements ClientModInitializer {

    // Tombol buka menu pilih model: default 'M'
    public static KeyBinding openModelMenuKey;

    @Override
    public void onInitializeClient() {
        // Daftar keybind
        openModelMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.customplayermodel.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "category.customplayermodel"
        ));

        // Daftarkan renderer & model layer
        CPMClientRegistry.register();

        // Inisialisasi model manager
        CPMModelManager.getInstance().init();

        // Bersihkan model saat client shutdown (hemat RAM)
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            CPMModelManager.getInstance().clearAll();
            CustomPlayerModelMod.LOGGER.info("[CPM] Model cache cleared on shutdown.");
        });

        // Daftar tick event untuk tombol
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openModelMenuKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new ModelSelectorScreen());
                }
            }
        });

        CustomPlayerModelMod.LOGGER.info("[CPM] Client initialized. Tekan 'M' untuk pilih model.");
    }
}
