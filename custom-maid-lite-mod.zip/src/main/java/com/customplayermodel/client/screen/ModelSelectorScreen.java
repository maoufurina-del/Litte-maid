package com.customplayermodel.client.screen;

import com.customplayermodel.CPMNetwork;
import com.customplayermodel.CPMServerState;
import com.customplayermodel.CustomPlayerModelMod;
import com.customplayermodel.client.model.CPMModelManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.*;

/**
 * GUI screen untuk memilih custom player model.
 * Desain ringan: list model sederhana, tombol Apply/Reset.
 * Tekan 'M' untuk membuka (keybind di CustomPlayerModelClient).
 */
public class ModelSelectorScreen extends Screen {

    private static final int LIST_ITEM_HEIGHT = 20;
    private static final int PANEL_WIDTH = 200;
    private static final int PANEL_HEIGHT = 300;

    private final List<String> modelIds = new ArrayList<>();
    private final List<String> modelNames = new ArrayList<>();
    private int selectedIndex = -1;
    private int scrollOffset = 0;

    private ButtonWidget applyButton;
    private ButtonWidget resetButton;
    private ButtonWidget refreshButton;

    public ModelSelectorScreen() {
        super(Text.translatable("screen.customplayermodel.model_selector"));
        // Muat daftar model
        Map<String, String> models = CPMModelManager.getInstance().getAvailableModels();
        modelIds.addAll(models.keySet());
        modelNames.addAll(models.values());
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;
        int panelX = cx - PANEL_WIDTH / 2;
        int panelY = cy - PANEL_HEIGHT / 2;

        // Tombol Apply
        applyButton = ButtonWidget.builder(
            Text.translatable("gui.customplayermodel.apply"),
            btn -> applyModel()
        ).dimensions(panelX, panelY + PANEL_HEIGHT + 5, 90, 20).build();
        applyButton.active = false;
        this.addDrawableChild(applyButton);

        // Tombol Reset
        resetButton = ButtonWidget.builder(
            Text.translatable("gui.customplayermodel.reset"),
            btn -> resetModel()
        ).dimensions(panelX + 95, panelY + PANEL_HEIGHT + 5, 90, 20).build();
        this.addDrawableChild(resetButton);

        // Tombol Refresh
        refreshButton = ButtonWidget.builder(
            Text.literal("⟳ Refresh"),
            btn -> {
                CPMModelManager.getInstance().refreshAvailableModels();
                modelIds.clear();
                modelNames.clear();
                Map<String, String> models = CPMModelManager.getInstance().getAvailableModels();
                modelIds.addAll(models.keySet());
                modelNames.addAll(models.values());
                selectedIndex = -1;
                applyButton.active = false;
            }
        ).dimensions(panelX + PANEL_WIDTH - 60, panelY - 22, 60, 18).build();
        this.addDrawableChild(refreshButton);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int cx = this.width / 2;
        int cy = this.height / 2;
        int panelX = cx - PANEL_WIDTH / 2;
        int panelY = cy - PANEL_HEIGHT / 2;

        // Background panel
        context.fill(panelX - 5, panelY - 25, panelX + PANEL_WIDTH + 5, panelY + PANEL_HEIGHT + 5, 0xAA000000);

        // Judul
        context.drawCenteredTextWithShadow(this.textRenderer,
            this.title, cx, panelY - 18, 0xFFFFFF);

        // Info folder model
        String folderPath = CPMModelManager.getInstance().getModelsDir() != null
            ? "config/customplayermodel/models/"
            : "Folder tidak tersedia";
        context.drawTextWithShadow(this.textRenderer,
            Text.literal("📁 " + folderPath), panelX, panelY - 8, 0xAAAAAA);

        // List model
        int visibleItems = PANEL_HEIGHT / LIST_ITEM_HEIGHT;
        for (int i = 0; i < visibleItems; i++) {
            int idx = i + scrollOffset;
            if (idx >= modelIds.size()) break;

            int itemY = panelY + i * LIST_ITEM_HEIGHT;
            boolean isSelected = idx == selectedIndex;
            boolean isHovered = mouseX >= panelX && mouseX <= panelX + PANEL_WIDTH
                    && mouseY >= itemY && mouseY < itemY + LIST_ITEM_HEIGHT;

            // Background item
            if (isSelected) {
                context.fill(panelX, itemY, panelX + PANEL_WIDTH, itemY + LIST_ITEM_HEIGHT, 0xAA3366FF);
            } else if (isHovered) {
                context.fill(panelX, itemY, panelX + PANEL_WIDTH, itemY + LIST_ITEM_HEIGHT, 0x44FFFFFF);
            } else if (idx % 2 == 0) {
                context.fill(panelX, itemY, panelX + PANEL_WIDTH, itemY + LIST_ITEM_HEIGHT, 0x22FFFFFF);
            }

            // Nama model
            context.drawTextWithShadow(this.textRenderer,
                Text.literal(modelNames.get(idx)),
                panelX + 5, itemY + 5,
                isSelected ? 0xFFFF88 : 0xFFFFFF);
        }

        // Pesan jika tidak ada model
        if (modelIds.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Tidak ada model ditemukan."),
                cx, cy - 10, 0xAAAAAA);
            context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Taruh file .json di folder models/"),
                cx, cy + 5, 0x888888);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int cx = this.width / 2;
        int cy = this.height / 2;
        int panelX = cx - PANEL_WIDTH / 2;
        int panelY = cy - PANEL_HEIGHT / 2;
        int visibleItems = PANEL_HEIGHT / LIST_ITEM_HEIGHT;

        for (int i = 0; i < visibleItems; i++) {
            int idx = i + scrollOffset;
            if (idx >= modelIds.size()) break;
            int itemY = panelY + i * LIST_ITEM_HEIGHT;
            if (mouseX >= panelX && mouseX <= panelX + PANEL_WIDTH
                    && mouseY >= itemY && mouseY < itemY + LIST_ITEM_HEIGHT) {
                selectedIndex = idx;
                applyButton.active = true;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int maxScroll = Math.max(0, modelIds.size() - PANEL_HEIGHT / LIST_ITEM_HEIGHT);
        scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - verticalAmount));
        return true;
    }

    private void applyModel() {
        if (selectedIndex < 0 || selectedIndex >= modelIds.size()) return;
        String modelId = modelIds.get(selectedIndex);

        // Kirim ke server
        ClientPlayNetworking.send(new CPMNetwork.ModelSyncPayload(modelId));

        // Update lokal langsung (biar responsif)
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            CPMServerState.setPlayerModel(client.player.getUuid(), modelId);
        }

        CustomPlayerModelMod.LOGGER.info("[CPM] Applied model: {}", modelId);
        this.close();
    }

    private void resetModel() {
        ClientPlayNetworking.send(new CPMNetwork.ModelSyncPayload(""));
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            CPMServerState.setPlayerModel(client.player.getUuid(), "");
        }
        CustomPlayerModelMod.LOGGER.info("[CPM] Model reset ke default.");
        this.close();
    }

    @Override
    public boolean shouldPause() {
        return false; // Jangan pause game saat buka menu model
    }
}
