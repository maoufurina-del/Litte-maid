package com.customplayermodel.client.screen;

import com.customplayermodel.client.model.CPMModelManager;
import com.customplayermodel.entity.MaidEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.*;

/**
 * GUI untuk mengganti model maid saat klik kanan maid sambil jongkok (shift+klik).
 * Sama seperti ModelSelectorScreen tapi untuk entity maid (bukan player).
 */
public class MaidModelScreen extends Screen {

    private static final int LIST_ITEM_HEIGHT = 20;
    private static final int PANEL_W = 210;
    private static final int PANEL_H = 280;

    private final MaidEntity maid;
    private final List<String> modelIds   = new ArrayList<>();
    private final List<String> modelNames = new ArrayList<>();
    private int selectedIndex = -1;
    private int scrollOffset  = 0;

    private ButtonWidget applyBtn;

    public MaidModelScreen(MaidEntity maid) {
        super(Text.literal("§d✿ Ganti Model Maid"));
        this.maid = maid;
        Map<String, String> models = CPMModelManager.getInstance().getAvailableModels();
        modelIds.addAll(models.keySet());
        modelNames.addAll(models.values());

        // Pre-select model saat ini
        String current = maid.getModelId();
        if (!current.isBlank()) {
            int idx = modelIds.indexOf(current);
            if (idx >= 0) selectedIndex = idx;
        }
    }

    @Override
    protected void init() {
        int px = this.width / 2 - PANEL_W / 2;
        int py = this.height / 2 - PANEL_H / 2;

        applyBtn = ButtonWidget.builder(
            Text.literal("§aTerapkan"),
            btn -> applyModel()
        ).dimensions(px, py + PANEL_H + 6, PANEL_W / 2 - 3, 20).build();
        applyBtn.active = selectedIndex >= 0;
        this.addDrawableChild(applyBtn);

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("§cReset Default"),
            btn -> resetModel()
        ).dimensions(px + PANEL_W / 2 + 3, py + PANEL_H + 6, PANEL_W / 2 - 3, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("⟳"),
            btn -> refreshList()
        ).dimensions(px + PANEL_W - 22, py - 20, 22, 16).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        this.renderBackground(ctx, mx, my, delta);

        int px = this.width / 2 - PANEL_W / 2;
        int py = this.height / 2 - PANEL_H / 2;

        // Panel background
        ctx.fill(px - 4, py - 26, px + PANEL_W + 4, py + PANEL_H + 4, 0xBB1A001A);

        // Judul
        ctx.drawCenteredTextWithShadow(textRenderer, this.title, this.width / 2, py - 20, 0xFFAAFF);

        // Info nama maid
        String maidName = maid.hasCustomName()
            ? maid.getCustomName().getString()
            : "Maid";
        ctx.drawTextWithShadow(textRenderer,
            Text.literal("§7Maid: §f" + maidName),
            px, py - 10, 0xFFFFFF);

        // Model saat ini
        String curModel = maid.getModelId().isBlank() ? "Default" : maid.getModelId();
        ctx.drawTextWithShadow(textRenderer,
            Text.literal("§7Model: §e" + curModel),
            px + PANEL_W / 2, py - 10, 0xFFFFFF);

        // Daftar model
        int visible = PANEL_H / LIST_ITEM_HEIGHT;
        for (int i = 0; i < visible; i++) {
            int idx = i + scrollOffset;
            if (idx >= modelIds.size()) break;

            int iy = py + i * LIST_ITEM_HEIGHT;
            boolean sel = idx == selectedIndex;
            boolean hov = mx >= px && mx <= px + PANEL_W && my >= iy && my < iy + LIST_ITEM_HEIGHT;

            if (sel)       ctx.fill(px, iy, px + PANEL_W, iy + LIST_ITEM_HEIGHT, 0xBB7722BB);
            else if (hov)  ctx.fill(px, iy, px + PANEL_W, iy + LIST_ITEM_HEIGHT, 0x44CC88FF);
            else if (idx % 2 == 0) ctx.fill(px, iy, px + PANEL_W, iy + LIST_ITEM_HEIGHT, 0x22FFFFFF);

            ctx.drawTextWithShadow(textRenderer,
                Text.literal((sel ? "§d▶ " : "§7  ") + modelNames.get(idx)),
                px + 6, iy + 5, sel ? 0xFFCCFF : 0xDDDDDD);
        }

        if (modelIds.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§7Taruh file .json di:"),
                this.width / 2, this.height / 2 - 12, 0xAAAAAA);
            ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§econfig/customplayermodel/models/"),
                this.width / 2, this.height / 2 + 2, 0xFFFF88);
        }

        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int px = this.width / 2 - PANEL_W / 2;
        int py = this.height / 2 - PANEL_H / 2;
        int visible = PANEL_H / LIST_ITEM_HEIGHT;

        for (int i = 0; i < visible; i++) {
            int idx = i + scrollOffset;
            if (idx >= modelIds.size()) break;
            int iy = py + i * LIST_ITEM_HEIGHT;
            if (mx >= px && mx <= px + PANEL_W && my >= iy && my < iy + LIST_ITEM_HEIGHT) {
                selectedIndex = idx;
                applyBtn.active = true;
                return true;
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmt, double vAmt) {
        int max = Math.max(0, modelIds.size() - PANEL_H / LIST_ITEM_HEIGHT);
        scrollOffset = (int) Math.max(0, Math.min(max, scrollOffset - vAmt));
        return true;
    }

    private void applyModel() {
        if (selectedIndex < 0 || selectedIndex >= modelIds.size()) return;
        String modelId = modelIds.get(selectedIndex);
        // Kirim ke server via packet
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
            new com.customplayermodel.CPMNetwork.MaidModelSyncPayload(maid.getId(), modelId)
        );
        this.close();
    }

    private void resetModel() {
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
            new com.customplayermodel.CPMNetwork.MaidModelSyncPayload(maid.getId(), "")
        );
        this.close();
    }

    private void refreshList() {
        CPMModelManager.getInstance().refreshAvailableModels();
        modelIds.clear();
        modelNames.clear();
        modelIds.addAll(CPMModelManager.getInstance().getAvailableModels().keySet());
        modelNames.addAll(CPMModelManager.getInstance().getAvailableModels().values());
        selectedIndex = -1;
        applyBtn.active = false;
    }

    @Override
    public boolean shouldPause() { return false; }
}
