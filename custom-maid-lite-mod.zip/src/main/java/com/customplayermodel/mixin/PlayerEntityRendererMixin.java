package com.customplayermodel.mixin;

import com.customplayermodel.CPMServerState;
import com.customplayermodel.client.model.CPMModelData;
import com.customplayermodel.client.model.CPMModelManager;
import com.customplayermodel.client.renderer.CPMPlayerRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;

/**
 * Mixin ke PlayerEntityRenderer.
 * Intercept render player: jika player punya custom model, delegasikan ke CPMPlayerRenderer.
 * Kalau tidak ada, biarkan renderer vanilla berjalan normal.
 */
@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {

    @Inject(
        method = "render",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onRender(
            AbstractClientPlayerEntity player,
            float yaw,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        // Cek apakah player ini punya custom model
        String modelId = CPMServerState.getPlayerModel(player.getUuid());
        if (modelId == null || modelId.isBlank()) return; // tidak ada model, render vanilla

        Optional<CPMModelData> modelData = CPMModelManager.getInstance().getModel(modelId);
        if (modelData.isEmpty()) return; // model tidak ditemukan, render vanilla

        // Render custom model, cancel vanilla render
        CPMPlayerRenderer.render(player, modelData.get(), yaw, tickDelta, matrices, vertexConsumers, light);
        ci.cancel();
    }
}
