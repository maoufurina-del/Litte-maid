package com.customplayermodel.entity;

import com.customplayermodel.CustomPlayerModelMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    public static final EntityType<MaidEntity> MAID = Registry.register(
        Registries.ENTITY_TYPE,
        Identifier.of(CustomPlayerModelMod.MOD_ID, "maid"),
        FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, MaidEntity::new)
            .dimensions(EntityDimensions.fixed(0.5f, 1.7f))   // Lebih kecil dari player
            .trackRangeBlocks(40)                              // Hemat bandwidth/RAM
            .trackedUpdateRate(3)                              // Update lebih jarang (hemat CPU)
            .build()
    );

    public static void register() {
        CustomPlayerModelMod.LOGGER.info("[CPM] Maid entity registered.");
    }
}
