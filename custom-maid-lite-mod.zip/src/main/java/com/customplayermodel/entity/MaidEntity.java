package com.customplayermodel.entity;

import com.customplayermodel.CustomPlayerModelMod;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * MaidEntity: companion maid yang mengikuti pemilik.
 *
 * Fitur (ringan, tidak makan RAM):
 * - Follow owner (pakai FollowOwnerGoal bawaan Minecraft)
 * - Sit/stand dengan klik kanan
 * - Pickup item di tanah (opsional)
 * - Custom model (YSM format) per maid
 * - Nama bisa diubah dengan name tag
 *
 * Tidak ada fitur berat seperti combat AI kompleks, inventory luas,
 * atau pathfinding khusus — semua pakai sistem Minecraft vanilla agar ringan.
 */
public class MaidEntity extends TameableEntity {

    // NBT keys
    private static final String NBT_MODEL_ID = "ModelId";
    private static final String NBT_MAID_NAME = "MaidName";

    // Model ID yang dipakai maid ini (bisa berbeda tiap maid)
    private String modelId = "";
    // State: duduk atau berdiri
    private boolean isSitting = false;

    public MaidEntity(EntityType<? extends TameableEntity> entityType, World world) {
        super(entityType, world);
        this.setTamed(false);
    }

    // ========== Attribute default ==========
    public static DefaultAttributeContainer.Builder createMaidAttributes() {
        return MobEntity.createMobAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)        // 10 hati
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)    // Sedikit lebih lambat dari player
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0)      // Range follow pendek (hemat pathfinding)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2.0);     // Damage minimal
    }

    // ========== AI Goals ==========
    @Override
    protected void initGoals() {
        // Priority 1: duduk jika diminta
        this.goalSelector.add(1, new SitGoal(this));

        // Priority 2: jangan jalan ke air / bahaya
        this.goalSelector.add(2, new EscapeDangerGoal(this, 1.5));

        // Priority 3: follow owner
        this.goalSelector.add(3, new FollowOwnerGoal(this, 1.0, 6.0f, 2.0f, false));

        // Priority 4: wander random (saat tidak ada owner)
        this.goalSelector.add(4, new WanderAroundGoal(this, 0.8, 40)); // cooldown 40 tick = 2 detik

        // Priority 5: look at player terdekat
        this.goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));

        // Priority 6: look random
        this.goalSelector.add(6, new LookAroundGoal(this));
    }

    // ========== Interaksi klik kanan ==========
    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack held = player.getStackInHand(hand);
        World world = this.getWorld();

        // Tame dengan sugar / cake
        if (!this.isTamed()) {
            if (held.isOf(Items.SUGAR) || held.isOf(Items.CAKE)) {
                if (!world.isClient) {
                    if (this.random.nextFloat() < 0.33f) { // 33% chance tame
                        this.setOwner(player);
                        this.setTamed(true);
                        this.playSound(SoundEvents.ENTITY_CAT_PURR, 1.0f, 1.0f);
                        player.sendMessage(Text.literal("§aMaid telah dijinakkan! Halo, " + player.getName().getString() + "!"), true);
                    } else {
                        this.playSound(SoundEvents.ENTITY_CAT_HISS, 1.0f, 1.0f);
                        player.sendMessage(Text.literal("§cMaid menolak... coba lagi."), true);
                    }
                    if (!player.isCreative()) held.decrement(1);
                }
                return ActionResult.SUCCESS;
            }
            return super.interactMob(player, hand);
        }

        // Hanya owner yang bisa interaksi
        if (!player.getUuid().equals(this.getOwnerUuid()) && !player.isCreative()) {
            player.sendMessage(Text.literal("§cMaid ini bukan milikmu!"), true);
            return ActionResult.FAIL;
        }

        // Klik kanan = toggle sit/stand
        if (!world.isClient) {
            this.isSitting = !this.isSitting;
            this.setSitting(this.isSitting);
            this.playSound(
                this.isSitting ? SoundEvents.ENTITY_CAT_PURR : SoundEvents.ENTITY_CAT_STRAY_AMBIENT,
                0.6f, 1.2f
            );
            player.sendMessage(
                Text.literal(this.isSitting ? "§eMaid sedang duduk." : "§eMaid siap mengikuti!"),
                true
            );
        }
        return ActionResult.SUCCESS;
    }

    // ========== Suara ==========
    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return this.isTamed() ? SoundEvents.ENTITY_CAT_PURR : SoundEvents.ENTITY_CAT_STRAY_AMBIENT;
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_CAT_HISS;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_CAT_DEATH;
    }

    // ========== NBT Save/Load ==========
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString(NBT_MODEL_ID, this.modelId);
        nbt.putBoolean("Sitting", this.isSitting);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.modelId = nbt.getString(NBT_MODEL_ID);
        this.isSitting = nbt.getBoolean("Sitting");
        this.setSitting(this.isSitting);
    }

    // ========== Getters/Setters ==========
    public String getModelId() { return modelId; }

    public void setModelId(String modelId) {
        this.modelId = modelId != null ? modelId : "";
    }

    // TameableEntity requires this
    @Nullable
    @Override
    public MaidEntity createChild(ServerWorld world, net.minecraft.entity.passive.PassiveEntity entity) {
        return null; // Maid tidak bisa breeding
    }

    @Override
    public boolean canBreedWith(net.minecraft.entity.passive.AnimalEntity other) {
        return false;
    }
}
