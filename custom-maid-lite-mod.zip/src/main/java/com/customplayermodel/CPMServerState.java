package com.customplayermodel;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Menyimpan pilihan model player di server.
 * Menggunakan ConcurrentHashMap agar thread-safe dan ringan (tidak perlu disk I/O per tick).
 */
public class CPMServerState {

    // Map: PlayerUUID -> Model ID ("" = default Steve/Alex)
    private static final Map<UUID, String> playerModels = new ConcurrentHashMap<>();

    public static void setPlayerModel(UUID playerUUID, String modelId) {
        if (modelId == null || modelId.isBlank()) {
            playerModels.remove(playerUUID);
        } else {
            playerModels.put(playerUUID, modelId);
        }
    }

    public static String getPlayerModel(UUID playerUUID) {
        return playerModels.getOrDefault(playerUUID, "");
    }

    public static boolean hasCustomModel(UUID playerUUID) {
        return playerModels.containsKey(playerUUID);
    }

    public static void removePlayer(UUID playerUUID) {
        playerModels.remove(playerUUID);
    }
}
