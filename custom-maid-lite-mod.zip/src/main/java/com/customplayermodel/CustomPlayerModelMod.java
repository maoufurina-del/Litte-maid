package com.customplayermodel;

import com.customplayermodel.entity.ModEntities;
import com.customplayermodel.entity.ModItems;
import com.customplayermodel.entity.MaidEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomPlayerModelMod implements ModInitializer {
    public static final String MOD_ID = "customplayermodel";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[CustomPlayerModel] Inisialisasi mod...");

        // Daftarkan entity
        ModEntities.register();

        // Daftarkan item (spawn egg, item group)
        ModItems.register();

        // Daftarkan attribute default maid
        FabricDefaultAttributeRegistry.register(
            ModEntities.MAID,
            MaidEntity.createMaidAttributes()
        );

        // Daftarkan network packets
        CPMNetwork.registerPackets();

        LOGGER.info("[CustomPlayerModel] Mod siap! Tekan M untuk pilih model player.");
        LOGGER.info("[CustomPlayerModel] Gunakan Spawn Egg Maid untuk memanggil maid.");
    }
}
