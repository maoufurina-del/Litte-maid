# 📱 Cara Build JAR Pakai HP Saja (Tanpa PC/Laptop)

Ikuti langkah ini pelan-pelan. Semua bisa dilakukan dari browser HP.
Build otomatis di cloud GitHub (gratis!), kamu tinggal download hasilnya.

---

## Langkah 1 — Buat Akun GitHub (Gratis)

1. Buka **github.com** di browser HP
2. Klik **Sign up**
3. Isi email, buat password, pilih username
4. Verifikasi email kamu
5. Login ke GitHub

---

## Langkah 2 — Buat Repository Baru

1. Di github.com, klik tombol **+** (pojok kanan atas)
2. Pilih **New repository**
3. Isi:
   - Repository name: `custom-maid-mod`
   - Pilih **Public**
4. Klik **Create repository**

---

## Langkah 3 — Upload Semua File Mod

Di halaman repo yang baru dibuat:

1. Klik **uploading an existing file**  
   *(atau klik Add file → Upload files)*

2. Upload **semua file** dari folder `minecraft-mod/` ini:
   - `build.gradle`
   - `settings.gradle`
   - `gradle.properties`
   - `gradlew` *(penting!)*
   - `gradlew.bat`
   - `LICENSE-MIT`
   - Folder `gradle/` (beserta isinya)
   - Folder `src/` (beserta semua isinya)
   - Folder `.github/` (beserta `workflows/build.yml`)

   > **Tips:** Di GitHub web, kamu bisa drag & drop banyak file sekaligus

3. Scroll ke bawah, klik **Commit changes**

---

## Langkah 4 — Tunggu Build Otomatis

Setelah upload, GitHub Actions otomatis mulai build JAR-nya.

1. Klik tab **Actions** di repo kamu
2. Kamu akan lihat workflow **"Build Maid Mod JAR"** sedang berjalan
3. Tunggu sampai ada centang hijau ✅ (biasanya 5-15 menit)
4. Kalau ada ❌ merah → klik untuk lihat error, hubungi saya

---

## Langkah 5 — Download JAR

1. Klik workflow yang sudah selesai (centang hijau ✅)
2. Scroll ke bawah, cari bagian **Artifacts**
3. Klik **custom-maid-mod-1.20.1**
4. File ZIP akan terdownload — extract → ambil file `.jar` di dalamnya

---

## Langkah 6 — Install di Mojo Launcher

1. Copy file `.jar` ke folder `.minecraft/mods/` di HP kamu
2. Pastikan sudah ada:
   - **Fabric Loader 0.15.x** untuk Minecraft 1.20.1
   - **Fabric API 0.91.x** untuk 1.20.1
3. Buka Mojo Launcher → pilih profil Fabric 1.20.1 → Play!

---

## 🎮 Cara Pakai Mod di Game

| Aksi | Cara |
|---|---|
| Spawn maid | Creative mode → tab Custom Player Model → Maid Spawn Egg |
| Jinakkan maid | Klik kanan maid dengan **Gula** (33% berhasil) |
| Duduk/berdiri | Klik kanan maid yang sudah jinak |
| Ganti model maid | Shift + klik kanan maid |
| Ganti model player | Tekan tombol **M** |

---

## 📁 Cara Tambah Model (Opsional)

Taruh file model `.json` di:
```
.minecraft/config/customplayermodel/models/
```
Lihat contoh format di file `sample_model_format.json`

---

## ❓ Butuh Bantuan?

Kalau ada error saat build, screenshot halaman Actions-nya dan tunjukkan ke saya!
